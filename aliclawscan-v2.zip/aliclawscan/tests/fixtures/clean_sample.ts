// Clean sample — no security issues expected
import { readFile } from "fs/promises";
import path from "path";

const CONFIG_PATH = path.join(__dirname, "config.json");

export async function loadConfig(): Promise<Record<string, string>> {
  const raw = await readFile(CONFIG_PATH, "utf-8");
  return JSON.parse(raw);
}

export function greet(name: string): string {
  return `Hello, ${name}!`;
}
