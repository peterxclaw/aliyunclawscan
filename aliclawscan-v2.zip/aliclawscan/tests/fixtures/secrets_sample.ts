// Secrets sample — contains hardcoded secrets
const AWS_ACCESS_KEY = "AKIAIOSFODNN7EXAMPLE";
const AWS_SECRET = "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY";

const dbUrl = "mongodb://admin:P@ssw0rd123@prod.example.com:27017/mydb";

const jwtToken =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIn0.dozjgNryP4J3jVmNHl0w5N_XgL0n3I9PlFUP0THsR8U";

export const config = {
  apiKey: "sk_live_51HqF2KLkjsdhfkjsdhfkjhsdkfjhskdjfh",
  password: "MySecretPassword123!",
};
