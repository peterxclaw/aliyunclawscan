// Injection vulnerabilities sample
import { exec } from "child_process";
import fs from "fs";

export function runCommand(userInput: string): void {
  // INJECT-001: Command injection
  exec("ls " + userInput);
}

export function evaluateCode(code: string): any {
  // INJECT-002: eval usage
  return eval(code);
}

export function readUserFile(filename: string): string {
  // INJECT-003: Path traversal
  return fs.readFileSync("./uploads/" + filename, "utf-8");
}

export function fetchUrl(url: string): Promise<Response> {
  // INJECT-005: SSRF risk
  return fetch(url);
}

export function renderHtml(content: string): void {
  // INJECT-006: innerHTML
  document.body.innerHTML = content;
}
